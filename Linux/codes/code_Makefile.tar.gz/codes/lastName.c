#include <stdio.h>
#include "firstName.h"

int main (){
  echo_firstName();
  printf("hello,my last name is chuanwei\n");
  return 0;
}
