#include <stdio.h>
#include "firstName.h"

int echo_firstName (){
  printf("hello,my first name is yu\n");
  return 0;
}
