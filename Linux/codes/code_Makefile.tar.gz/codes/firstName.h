#ifndef FIRSTNAME_H
#define FIRSTNAME_H

int echo_firstName();

#endif
